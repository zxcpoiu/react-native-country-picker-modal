self.__precacheManifest = [
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/react-native-country-picker-modal/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "2b7112f6e08b03ee4aa3",
    "url": "/react-native-country-picker-modal/static/js/app.3433b3ef.chunk.js"
  },
  {
    "revision": "9f1ced4a29c6269fd4f4",
    "url": "/react-native-country-picker-modal/static/js/runtime~app.86aa0dc2.js"
  },
  {
    "revision": "12466ff36f23f268e95685369ab6883b",
    "url": "/react-native-country-picker-modal/static/media/close.android.12466ff3.png"
  },
  {
    "revision": "0dc8a49d999a851497c910bbb0afbba2",
    "url": "/react-native-country-picker-modal/static/media/close.ios.0dc8a49d.png"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/react-native-country-picker-modal/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "16c8b9ffdc413749d9c7c3b7478f9d45",
    "url": "/react-native-country-picker-modal/index.html"
  },
  {
    "revision": "8527e98a81817cd419e52b85dcff3da5",
    "url": "/react-native-country-picker-modal/manifest.json"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/react-native-country-picker-modal/serve.json"
  },
  {
    "revision": "3db7fb5edb74e8aea5c3",
    "url": "/react-native-country-picker-modal/static/js/2.e4056eaf.chunk.js"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/react-native-country-picker-modal/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/react-native-country-picker-modal/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/react-native-country-picker-modal/./fonts/Ionicons.ttf"
  },
  {
    "revision": "5e695e96a003a79f7f97060bf49409a9",
    "url": "/react-native-country-picker-modal/expo-service-worker.js"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/react-native-country-picker-modal/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/react-native-country-picker-modal/./fonts/Foundation.ttf"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/react-native-country-picker-modal/favicon.ico"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/react-native-country-picker-modal/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/react-native-country-picker-modal/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/react-native-country-picker-modal/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/react-native-country-picker-modal/./fonts/AntDesign.ttf"
  }
];